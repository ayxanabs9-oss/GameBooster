package com.gamebooster.app

import android.content.Context
import android.util.Log
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer

/**
 * SUNUCU_KURULUMU.md dosyasındaki adımları tamamladıktan sonra
 * aşağıdaki alanları KENDİ bilgilerinle doldur.
 *
 * Birden fazla sunucu eklemek istersen SERVERS listesine yeni bir
 * ServerConfig ekle; app otomatik olarak en düşük ping'i vereni seçer
 * (pickBestServer fonksiyonuna bak).
 */
data class ServerConfig(
    val name: String,           // örn. "Almanya"
    val endpoint: String,       // örn. "1.2.3.4:51820"
    val serverPublicKey: String,
    val clientPrivateKey: String,
    val clientAddress: String,  // örn. "10.0.0.2/32"
    val dns: String = "1.1.1.1"
)

object WireGuardServers {
    // TODO: SUNUCU_KURULUMU.md'ye göre kendi bilgilerini gir
    val SERVERS = listOf(
        ServerConfig(
            name = "Sunucu 1",
            endpoint = "SUNUCU_IP:51820",
            serverPublicKey = "SERVER_PUBLIC_KEY_BURAYA",
            clientPrivateKey = "CLIENT_PRIVATE_KEY_BURAYA",
            clientAddress = "10.0.0.2/32"
        )
        // İkinci bir lokasyon eklemek istersen buraya ikinci ServerConfig ekle
    )
}

class WireGuardManager(private val context: Context) {

    private var backend: GoBackend? = null
    private var currentTunnel: Tunnel? = null

    private val simpleTunnel = object : Tunnel {
        override fun getName(): String = "gamebooster"
        override fun onStateChange(newState: Tunnel.State) {
            Log.d("WireGuardManager", "Tünel durumu: $newState")
        }
    }

    fun init() {
        backend = GoBackend(context)
    }

    private fun buildConfig(server: ServerConfig): Config {
        val iface = Interface.Builder()
            .parsePrivateKey(server.clientPrivateKey)
            .addAddress(InetNetwork.parse(server.clientAddress))
            .parseDnsServers(server.dns)
            .build()

        val peer = Peer.Builder()
            .parsePublicKey(server.serverPublicKey)
            .setEndpoint(InetEndpoint.parse(server.endpoint))
            .parseAllowedIPs("0.0.0.0/0")
            .setPersistentKeepalive(25)
            .build()

        return Config.Builder()
            .setInterface(iface)
            .addPeer(peer)
            .build()
    }

    /** En iyi sunucuyu ölçüp bağlanır. Şimdilik listedeki ilk sunucuyu kullanır;
     *  gerçek ping ölçümü eklemek için pingServer() fonksiyonunu doldurabilirsin. */
    fun connectBestServer(onResult: (success: Boolean, serverName: String) -> Unit) {
        val server = WireGuardServers.SERVERS.firstOrNull()
        if (server == null) {
            onResult(false, "Sunucu tanımlı değil")
            return
        }
        try {
            val config = buildConfig(server)
            backend?.setState(simpleTunnel, Tunnel.State.UP, config)
            currentTunnel = simpleTunnel
            onResult(true, server.name)
        } catch (e: Exception) {
            Log.e("WireGuardManager", "Bağlantı hatası", e)
            onResult(false, server.name)
        }
    }

    fun disconnect() {
        currentTunnel?.let {
            backend?.setState(it, Tunnel.State.DOWN, null)
        }
        currentTunnel = null
    }

    fun isConnected(): Boolean {
        return currentTunnel != null
    }
}
