package com.gamebooster.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log

class PerformanceBooster(private val context: Context) {

    /** Android 12+ üzerinde sistemin "oyun modu" performans profiline geçmesini ister. */
    fun requestHighPerformanceMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            // Sistem sadece izin verdiği ölçüde uygular; garantili "FPS artışı" değil,
            // ama CPU/GPU'yu performans moduna geçmeye teşvik eder.
            try {
                pm.isPowerSaveMode // sadece okuma - gerçek toggle sistem ayarındadır
            } catch (e: Exception) {
                Log.w("PerformanceBooster", "Performans modu okunamadı", e)
            }
        }
    }

    /** Arka plandaki uygulamaları kapatmayı dener.
     *  Not: Android 8+ sürümlerde üçüncü parti appler başka bir appi
     *  gerçekten "kill" edemez, sistem bunu ciddi şekilde kısıtlar.
     *  Bu fonksiyon sadece kendi sürecinin arka plan işlerini temizler
     *  ve kullanıcıya sistemin "Son Uygulamalar" ekranını açmayı önerir. */
    fun trimBackgroundLoad() {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        try {
            am.killBackgroundProcesses(context.packageName)
        } catch (e: SecurityException) {
            Log.w("PerformanceBooster", "Arka plan temizliği kısıtlı", e)
        }
    }

    /** DNS'i 1.1.1.1 (Cloudflare) olarak ayarlamak için sistem ayarına yönlendirir.
     *  Uygulama kod içinden sistem DNS'ini değiştiremez, kullanıcı onayı gerekir. */
    fun openPrivateDnsSettings() {
        val intent = android.content.Intent(Settings.ACTION_WIRELESS_SETTINGS)
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
