# GameBooster

Oyuna girince otomatik devreye giren performans + VPN tünel uygulaması.

## Neler yapar
- Belirlediğin oyun paketleri ön plana gelince otomatik tetiklenir
- Kendi kiraladığın sunucuya WireGuard ile bağlanır (ping düşürmeye yardımcı olabilir)
- Arka plan yükünü hafifletmeye çalışır, yüksek performans moduna geçmeyi ister
- Oyundan çıkınca VPN'i otomatik kapatır

## Kurulum sırası
1. `SUNUCU_KURULUMU.md` dosyasındaki adımlarla bir VPS'e WireGuard kur
2. `app/src/main/java/com/gamebooster/app/WireGuardManager.kt` içindeki
   `WireGuardServers.SERVERS` listesine kendi sunucu bilgilerini gir
3. `GameDetectorService.kt` içindeki `WATCHED_PACKAGES` setine izlemek
   istediğin oyunların paket adlarını ekle (Play Store linkinden bulunur:
   `...details?id=PAKET_ADI`)
4. Projeyi Android Studio'da aç, `Gradle Sync` yap
5. Telefona kur, uygulamayı aç:
   - "Kullanım İznini Ver" → ayarlardan GameBooster'a izin ver
   - "Boost'u Başlat" → VPN izni çıkacak, onayla

## Sınırlamalar (dürüst olmak gerekirse)
- Android güvenlik modeli üçüncü parti bir uygulamanın başka uygulamaları
  gerçek anlamda "kill" etmesine izin vermiyor; bu yüzden arka plan
  temizliği sınırlıdır.
- "FPS yükseltme" donanım sınırlarını aşamaz; yapılan şey CPU/GPU'yu daha
  agresif çalışmaya teşvik etmek ve gereksiz yükü azaltmaktır.
- Ping iyileşmesi sunucunun konumuna ve oyunun sunucusuna olan gerçek
  ağ rotasına bağlıdır, garanti değildir.
