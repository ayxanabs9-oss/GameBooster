# WireGuard Sunucu Kurulumu

## 1. VPS Kirala
Ucuz seçenekler: Hetzner (~4-5€/ay), DigitalOcean, Contabo.
- **Konum önemli**: Oyun sunucusuna coğrafi olarak yakın bir bölge seç
  (örn. oyun sunucun Avrupa'daysa Frankfurt/Almanya VPS al).
- İşletim sistemi: **Ubuntu 22.04**

## 2. Sunucuya Bağlan
```bash
ssh root@SUNUCU_IP
```

## 3. WireGuard Kur (tek komut)
```bash
apt update && apt install wireguard -y
```

## 4. Anahtar Çiftini Oluştur (sunucu için)
```bash
cd /etc/wireguard
umask 077
wg genkey | tee server_private.key | wg pubkey > server_public.key
```

## 5. Sunucu Config Dosyası
`/etc/wireguard/wg0.conf` oluştur:
```ini
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PrivateKey = <server_private.key içeriği>
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# --- Her telefon/arkadaş için bir [Peer] bloğu ekleyeceksin ---
[Peer]
PublicKey = <telefon1_public_key>
AllowedIPs = 10.0.0.2/32
```

## 6. IP Yönlendirmeyi Aç
```bash
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
sysctl -p
```

## 7. Başlat
```bash
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0
```

## 8. Her Kullanıcı (arkadaşların) İçin Anahtar Üret
Kendi bilgisayarında/telefonunda:
```bash
wg genkey | tee client_private.key | wg pubkey > client_public.key
```
`client_public.key` içeriğini sunucudaki `wg0.conf`'a yeni bir `[Peer]` olarak ekle,
her kişiye farklı bir `AllowedIPs` (10.0.0.3/32, 10.0.0.4/32...) ver.

## 9. Telefon Tarafı Config (uygulamaya girilecek)
```ini
[Interface]
PrivateKey = <client_private.key>
Address = 10.0.0.2/32
DNS = 1.1.1.1

[Peer]
PublicKey = <server_public.key içeriği>
Endpoint = SUNUCU_IP:51820
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
```

Bu bilgileri (PrivateKey, Address, ServerPublicKey, Endpoint) uygulamadaki
`WireGuardManager` sınıfına gireceksin — kod tarafı bunu bekliyor.

## Not
Birden fazla lokasyonda ("oto sunucu değiştirme" için) bu adımları farklı
VPS'lerde tekrarlayıp uygulamaya birkaç config ekleyeceksin; uygulama
aralarında ping'e göre otomatik geçiş yapacak (kod tarafında hazır).
